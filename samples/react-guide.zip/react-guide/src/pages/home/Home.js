import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import taskService from "../../service/taskService.js";

class Home extends Component {

  constructor(props) {
    super(props);

    this.state = {
      data: []
    };
  }

  componentDidMount() {
    taskService.getAllTasks().then(data => {
        console.log("SUCCESS",data);
        //this.setState({postContent: data})
    },(err) =>{
        console.log("ERROR",err);
    });
  }

  render() {
    return (
        <div>
         <p><Link to='/task/3455'>Roster</Link></p>
         <h1>HOME</h1>
        </div>
    );
  }
}

export default Home;