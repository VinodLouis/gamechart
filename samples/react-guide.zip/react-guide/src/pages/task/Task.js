import React, { Component } from 'react';

class Task extends Component {
  render() {
    return (
      <h1>TASK</h1>
    );
  }
}

export default Task;