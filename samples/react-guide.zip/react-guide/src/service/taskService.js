import axios from "axios";

export default{
    getAllTasks:function(){
        return axios.get("http://localhost:8082/task")
    }
}