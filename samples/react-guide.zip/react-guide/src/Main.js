import React, { Component } from 'react';
import { Switch, Route } from 'react-router'
import Home from './pages/home/Home.js';
import Task from './pages/task/Task.js';

class Main extends Component {
  render() {
    return (
        <Switch>
            <Route exact path='/' component={Home}/>
            <Route path='/task/:id' component={Task}/>
        </Switch>
    );
  }
}

export default Main;
